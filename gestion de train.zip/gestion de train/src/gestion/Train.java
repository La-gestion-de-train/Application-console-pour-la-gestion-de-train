package gestion;

public class Train {
	private  int id;
	private String nom;
	private int nbrPlaceN;
	private int nbrPlaceVIP;
	
	
	
	
	public Train(int id,String nom, int nbrPlaceN, int nbrPlaceVIP) {
		super();
		this.id=id;
		this.nom = nom;
		this.nbrPlaceN = nbrPlaceN;
		this.nbrPlaceVIP = nbrPlaceVIP;
	}
	
	public Train() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public int getNbrPlaceN() {
		return nbrPlaceN;
	}
	public void setNbrPlaceN(int nbrPlaceN) {
		this.nbrPlaceN = nbrPlaceN;
	}
	public int getNbrPlaceVIP() {
		return nbrPlaceVIP;
	}
	public void setNbrPlaceVIP(int nbrPlaceVIP) {
		this.nbrPlaceVIP = nbrPlaceVIP;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
	
	

}
