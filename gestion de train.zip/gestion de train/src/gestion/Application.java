package gestion;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Application {

	public static List<Trajet> trajets = new ArrayList<>();
	public static List<Train> trains = new ArrayList<>();

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		String vv = "0";
		// a.SaisieCategorieTrajet(cat, tra, pr);
		do {
			System.out.println("*****Menu Generale****\r\n" + "1.Ajouter Train\r\n" + "2.Ajouter Trajet\r\n"
					+ "3.Consulter les Trajets\r\n" + "4.Rechercher Un Trajer Par Ville Arrivée\r\n"
					+ "5.Acheter un Billet A\r\n" + "0. Quitter`\r\n");
			vv = scanner.nextLine();
			if (vv.equals("1")) {
				System.out.println("Saisir le Nom du Train :");
				String n = scanner.nextLine();
				System.out.println("Saisir le Nombres de places N :");
				int pn = scanner.nextInt();
				System.out.println("Saisir le Nombres de places VIP :");
				int pv = scanner.nextInt();
				trains.add(new Train(trains.size() + 1, n, pn, pv));
				for (Train t : trains)
					System.out.println(t.getId());
			} else if (vv.equals("2")) {
				System.out.println("Saisir la Ville de Depart :");
				String v1 = scanner.nextLine();
				System.out.println("Saisir la Ville d'Arrivée :");
				String v2 = scanner.nextLine();
				System.out.println("Saisir l'heure de Depart :");
				String h1 = scanner.nextLine();
				System.out.println("Saisir l'heure d'arrivée :");
				String h2 = scanner.nextLine();

				System.out.println("Saisir le Numero du train pour ce trajet :");
				int nT = scanner.nextInt();
				if (trains.size() < nT) {
					System.out.println("Vous avez tapez un nombre erroné ( entre 1 et " + trains.size() + ")");
					System.out.println("Saisir le Numero du train pour ce trajet :");
					nT = scanner.nextInt();
				}
				Train t = trains.get(nT - 1);
				Trajet tr = new Trajet(v1, v2, h1, h2);
				tr.setId(trajets.size() + 1);
				tr.setTrain(t);
				trajets.add(tr);

			} else if (vv.equals("3")) {
				System.out.println("---------- Liste des Trajet -----------------");
				System.out.println("num Trajet	Ville Depart	Ville Arrivee	H depart	H arrivee	Num Train");
				for (Trajet t : trajets) {
					System.out.println(t.getId() + "\t\t" + t.getVilleDepart() + "\t\t" + t.getVilleArrive() + "\t\t"
							+ t.getHeureDepart() + "\t\t" + t.getHeureArrive() + "\t\t" + t.getTrain().getId());
				}

				int r = scanner.nextInt();
			} else if (vv.equals("4")) {

				System.out.println("---------- Rechercher un Trajet -----------------");
				System.out.println("Saisir la Ville d'Arrivée :");
				String v2 = scanner.nextLine();

				System.out.println("num Trajet	Ville Depart	Ville Arrivee	H depart	H arrivee	Num Train");
				for (Trajet t : trajets) {

					if (t.getVilleArrive().toLowerCase().equals(v2.toLowerCase())) {

						System.out.println(t.getId() + "\t\t" + t.getVilleDepart() + "\t\t" + t.getVilleArrive()
								+ "\t\t" + t.getHeureDepart() + "\t\t" + t.getHeureArrive() + "\t\t"
								+ t.getTrain().getId());

					}
				}

				int r = scanner.nextInt();

			} else if (vv.equals("5")) {

				System.out.println("---------- Liste des Trajets -----------------");
				System.out.println("num Trajet	Ville Depart	Ville Arrivee	H depart	H arrivee	Num Train");
				for (Trajet t : trajets) {
					System.out.println(t.getId() + "\t\t" + t.getVilleDepart() + "\t\t" + t.getVilleArrive() + "\t\t"
							+ t.getHeureDepart() + "\t\t" + t.getHeureArrive() + "\t\t" + t.getTrain().getId());
				}
				System.out.println("Choisur le numero du trajet souhaiter :");
				int nT = scanner.nextInt();
				System.out.println("Place Normale ou VIP (0/1) :");
				int typePlace = scanner.nextInt();
				if(typePlace==0) {
					Trajet t=trajets.get(nT-1);
					if(t.getTrain().getNbrPlaceN()>=1) {
						t.getTrain().setNbrPlaceN(t.getTrain().getNbrPlaceN()-1);
						System.out.println("Merci pour votre Reservation - Votre Place Normale ");
					}else System.out.println("Pas de place disponible !!! ");
				}else if(typePlace==1) {
					Trajet t=trajets.get(nT-1);
					if(t.getTrain().getNbrPlaceVIP()>=1) {
						t.getTrain().setNbrPlaceVIP(t.getTrain().getNbrPlaceVIP()-1);
						System.out.println("Merci pour votre Reservation - Votre Place VIP ");
					}else System.out.println("Pas de place disponible !!! ");
				}
				
				System.out.println("Taper un nombre pour retourner");
				int r = scanner.nextInt();
				

			}

		} while (!vv.equals("0"));

	}

}
