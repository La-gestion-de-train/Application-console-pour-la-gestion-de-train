package gestion;

public class Trajet {
	private  int id;
	private String villeDepart,villeArrive,heureDepart,heureArrive;
	private Train train;
	
	
	public Train getTrain() {
		return train;
	}
	public void setTrain(Train train) {
		this.train = train;
	}
	public  int getId() {
		return id;
	}
	public  void setId(int id) {
		this.id = id;
	}
	public String getVilleDepart() {
		return villeDepart;
	}
	public void setVilleDepart(String villeDepart) {
		this.villeDepart = villeDepart;
	}
	public String getVilleArrive() {
		return villeArrive;
	}
	public void setVilleArrive(String villeArrive) {
		this.villeArrive = villeArrive;
	}
	public Trajet() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getHeureDepart() {
		return heureDepart;
	}
	public void setHeureDepart(String heureDepart) {
		this.heureDepart = heureDepart;
	}
	public String getHeureArrive() {
		return heureArrive;
	}
	public void setHeureArrive(String heureArrive) {
		this.heureArrive = heureArrive;
	}
	public Trajet(String villeDepart, String villeArrive, String heureDepart, String heureArrive) {
		super();
		this.villeDepart = villeDepart;
		this.villeArrive = villeArrive;
		this.heureDepart = heureDepart;
		this.heureArrive = heureArrive;
	}
	

}
